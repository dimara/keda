About
-----

python-monkey-business is a package that provides a decorator for
monkey-patching python functions at runtime.

Installation
------------

Using pip::

    pip install python-monkey-business

Or, to install from source::

    pip install -e git+https://github.com/theatlantic/python-monkey-business.git#egg=python-monkey-business

If the source is already checked out, use setuptools::

    python setup.py develop

Usage
-----

To use python-monkey-business to swap out a function in a class or module at runtime:

.. code-block:: python

    import monkeybiz

    from foomodule import FooClass
    import barmodule


    # This replaces FooClass.bar with our method
    @monkeybiz.patch(FooClass)
    def bar(original_fn, *args, **kwargs):
        print "Patched!"
        return original_fn(*args, **kwargs)

    # This replaces barmodule.baz with our function
    @monkeybiz.patch(barmodule)
    def baz(original_fn, *args, **kwargs):
        #...

The first argument to ``monkeybiz.patch`` can be either a module, a class,
or a list of modules and/or classes. The decorator also takes optional
``name`` and ``avoid_doublewrap`` keyword arguments. If ``name`` is omitted,
the name of the function being patched will be the name of the function being
decorated. If ``avoid_doublewrap`` is True (the default), then functions and
methods can only be patched once using this function.

Use ``monkeybiz.unpatch()`` to revert a monkey-patched function to its original.

License
-------

This code is licensed under the `Simplified BSD
License <http://opensource.org/licenses/BSD-2-Clause>`_. View the
``LICENSE`` file under the root directory for complete license and
copyright information.


