class NestedAdminPendingDeprecationWarning(PendingDeprecationWarning):
    pass
